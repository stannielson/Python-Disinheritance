"""Python disinheritance library"""


from ._disinherit import *
